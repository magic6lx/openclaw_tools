import http from 'http';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = 3003;

const CONFIG_DIR = join(__dirname, '../../config');
const CONFIG_FILE = join(CONFIG_DIR, 'openclaw_config.json');

let installState = { running: false, logs: [] };
let gatewayState = { running: false };

function sendJson(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(data));
}

function addLog(level, msg) {
  installState.logs.push({ timestamp: new Date().toISOString(), level, message: msg });
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
    res.end();
    return;
  }

  const url = req.url.split('?')[0];

  if (url === '/status' && req.method === 'GET') {
    sendJson(res, 200, { openClawStatus: existsSync(CONFIG_FILE) ? 'installed' : 'not_installed', gatewayRunning: gatewayState.running });
    return;
  }

  if (url === '/gateway/start' && req.method === 'POST') {
    if (gatewayState.running) return sendJson(res, 200, { success: false, message: 'Gateway 已在运行' });
    addLog('INFO', 'Gateway 启动功能开发中...');
    gatewayState.running = true;
    sendJson(res, 200, { success: true });
    return;
  }

  if (url === '/gateway/stop' && req.method === 'POST') {
    if (!gatewayState.running) return sendJson(res, 200, { success: false, message: 'Gateway 未运行' });
    addLog('INFO', 'Gateway 停止功能开发中...');
    gatewayState.running = false;
    sendJson(res, 200, { success: true });
    return;
  }

  if (url === '/install/start' && req.method === 'POST') {
    if (installState.running) return sendJson(res, 200, { success: false, message: '安装已在进行中' });
    installState = { running: true, logs: [] };
    addLog('INFO', '开始安装 OpenClaw...');
    addLog('INFO', '正在连接安装源...');
    addLog('INFO', '下载组件中...');
    addLog('INFO', '安装配置中...');
    addLog('INFO', '安装完成！');
    installState.running = false;
    sendJson(res, 200, { success: true });
    return;
  }

  if (url === '/install/status' && req.method === 'GET') {
    sendJson(res, 200, { running: installState.running, logs: installState.logs });
    return;
  }

  if (url === '/config/export' && req.method === 'GET') {
    try {
      if (!existsSync(CONFIG_FILE)) {
        return sendJson(res, 200, { success: true, config: { version: '1.0.0', gateway: { port: 8080 }, openclaw: { installed: false } } });
      }
      const config = JSON.parse(readFileSync(CONFIG_FILE, 'utf-8'));
      sendJson(res, 200, { success: true, config });
    } catch (err) {
      sendJson(res, 200, { success: false, error: err.message });
    }
    return;
  }

  if (url === '/config/import' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const { config } = JSON.parse(body);
        if (!config) return sendJson(res, 200, { success: false, error: '配置文件为空' });
        if (!existsSync(CONFIG_DIR)) mkdirSync(CONFIG_DIR, { recursive: true });
        writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        addLog('INFO', '配置已导入');
        sendJson(res, 200, { success: true });
      } catch (err) {
        sendJson(res, 200, { success: false, error: err.message });
      }
    });
    return;
  }

  if (url === '/launcher/download' && req.method === 'GET') {
    sendJson(res, 200, { message: '下载功能开发中', url: '#' });
    return;
  }

  if (url === '/api/health' && req.method === 'GET') {
    sendJson(res, 200, { status: 'ok' });
    return;
  }

  sendJson(res, 404, { error: 'Not Found' });
});

server.listen(PORT, () => {
  console.log(`OpenClaw Launcher running on port ${PORT}`);
});
