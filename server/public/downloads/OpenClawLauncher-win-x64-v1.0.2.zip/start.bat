@echo off
chcp 65001 > nul 2>&1
echo ========================================
echo   OpenClaw Launcher
echo ========================================
echo.

cd /d "%~dp0"

echo [1/3] 清理端口 3003...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :3003 ^| findstr LISTENING') do (
    taskkill /F /PID %%a > nul 2>&1
)

echo [2/3] 启动 Launcher 服务...
start "OpenClaw-Launcher" cmd /k "node index.js"

echo [3/3] 等待服务启动...
timeout /t 2 /nobreak > nul

echo.
echo ========================================
echo   Launcher 已启动！
echo   访问 http://127.0.0.1:3003
echo ========================================
echo.
echo 按任意键关闭此窗口...
pause > nul
